import './part-2';
import { testClickup } from './part-2';

// values that are to be parameterized and retrieved from a confiuration file or data source
const testToken = 'pk_54646532_7STX20R3MPRLAL0YR2LRKMQMPRV87PGD';
const testUrl = 'https://api.clickup.com/api/v2/oauth/';
const apiTest = new testClickup(testToken, testUrl);

const client_id = 'tomDalsin';
const client_secret = 'iOnlyStudiedThisLanguageForAFewHours';
const code = 'cc_54309GE4FAABCC4432=';

describe('#Part2', () => {
  // ======= AUTHORIZATION TESTS =========
  test('AUTH01-01: Happy path for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken(client_id, client_secret, code)
      ).toHaveProperty('access_token');
    };

  test('AUTH01-02: Garbage test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken(
          client_id,
          client_secret,
          code,
          'helloImJunk'
        )
      ).not.toHaveProperty('access_token');
    };

  test('AUTH01-03: missing client ID test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken('', client_secret, code)
      ).not.toHaveProperty('access_token');
    };

  test('AUTH01-04: invalid client ID test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken('I shouldnt be here', client_secret, code)
      ).not.toHaveProperty('access_token');
    };

  test('AUTH01-05: inject code in client ID test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken(
          '\'); console.write("nice security")',
          client_secret,
          code
        )
      ).not.toHaveProperty('access_token');
    };

  test('AUTH01-06: missing client secret test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken(client_id, '', code)
      ).not.toHaveProperty('access_token');
    };

  test('AUTH01-07: invalid client secret test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken(client_id, 'I dont believe in secrets', code)
      ).not.toHaveProperty('access_token');
    };

  test('AUTH01-08: inject code in client secret test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken(
          client_id,
          "'); I dont believe in secrets",
          code
        )
      ).not.toHaveProperty('access_token');
    };

  test('AUTH01-09: missing client code test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken(client_id, client_secret, '')
      ).not.toHaveProperty('access_token');
    };

  test('AUTH01-10: invalid client code test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken(
          client_id,
          client_secret,
          'ive cracked the code'
        )
      ).not.toHaveProperty('access_token');
    };

  test('AUTH01-11: inject code into code test for Get Access Token'),
    () => {
      expect(
        apiTest.authGetAccessToken(
          client_id,
          client_secret,
          "'); ive cracked the code"
        )
      ).not.toHaveProperty('access_token');
    };

  test('AUTH02-01: Happy path test for Get Authorized User'),
    () => {
      expect(apiTest.authGetAuthorizedUser(testToken)).toHaveProperty(
        'user.id'
      );
    };

  test('AUTH02-02: Missing token test for Get Authorized User'),
    () => {
      expect(apiTest.authGetAuthorizedUser('')).not.toHaveProperty('user.id');
    };

  // todo: authGetAuthorizedUser with bad token, authGetAuthorizedUser with junk param, code injection

  // todo: authGetAuthorizedTeams happy path, missing token, bad token, junk param, code injection
});
