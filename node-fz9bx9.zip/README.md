# Coding Exercise for Senior Test Automation Developer

Welcome to Zensurance’s coding exercise for TA positions.

This exercise consists of 3 parts:

- Part 1 will require you to write tests for a specific code provided, a key factor here is to come up with as many edge cases as you can in order to cover all possibilities.

- Part 2 will require you to create a set of tests in order to ensure the proper working of a provided API, a key factor here is to provide us with a comprehensive explanation on what tests did you apply, what’s the reason for applying them (what were you trying to cover when doing these tests) and evaluate the results of your tests by providing your own analysis of them.

- Part 3, you will be required to create a series of visual tests deending on the scenarios presented on a web page provided.

## Ready to start? Let's get to it!

## Part 1

The `part-1.ts` file calculates the `getPrice()` method, that given a list of prices, and a user, it calculates a result based on the rules and specifications outlined by the User and the Questions. Some users will see more information than others, and some will be disqualified from seeing any price based on some rules applied. The pricing engine handles these scenarios.

There is no interaction to be done in part-1.ts, this file only entails the business logic to which you will create test cases against.

Given the business logic of our Pricing Engine, and Users, please complete part-1.spec.ts file by creating as many test cases you can think of in order to make sure the code works properly.

We currently have Jest installed in our repository (see `package.json`). Feel free to install any testing library of your choice if you prefer to write tests with another library.

Once you’re done with it, you can send back a forked version of the code provided that includes your tests.

## Part 2

### Scenarios, Planning and Justification

Let’s imagine that your company assigned you to test an emerging task management system called (Clickup). Your company wants to know if it’s ok to use Clickup’s API to automate certain tasks. They need you to make sure that the API is responding as expected and also that security measures and standards are met.

How would you define your test scenario(s) and acceptance criteria? Please present the simple, clear and concise format.

### Test Automation

Based on your scenario(s) above and your approach, Using Javascript or Typescript (preferred) with the automation framework of your choice.
For testing purposes you will be provided with an API Token that must be used in order to communicate with certain access points.

API Token
pk_54646532_7STX20R3MPRLAL0YR2LRKMQMPRV87PGD

Note: This API Token was issued for the purposes of this assessment only, please don’t use it outside of the context of the current evaluation.
Clickup

- API documentation: <https://clickup.com/api>
- Authentication: <https://jsapi.apiary.io/apis/clickup20/introduction/authentication/personal-token.html>
- Keep in mind the rate limit while doing your tests: <https://jsapi.apiary.io/apis/clickup20/introduction/rate-limiting.html>
  Error Handling <https://jsapi.apiary.io/apis/clickup20/introduction/error-handling.html>

- The following are the skills that we assess:
  - Ability to understand a feature and break it down
  - Ability to define clear scenarios and acceptance criteria
  - Experience with setting up test data and resolving dependencies on external services
  - Experience in using known test libraries
  - Expertise automating tests
  - Passion for creating simple, effective and working solutions
  - Your tests must include:
    - Regression testing
    - Functional testing
    - Error handling
    - Authorization testing
    - Schema & data validation test
  - Bonus point tests
    - Performance test
    - Reply time test
    - Other you come up with
  - Make sure to cover at least the following features:
    - Adding, modifying and deleting tasks,
    - Access control to teams, spaces and folders

## Part 3

### Scenarios, Planning and Justification

You were hired by a new startup company dedicated to selling clothing and other items. Their engineering team created an e-commerce site and they want to know if it's complying with all standards.

A Git hub repository is provided to you so you can clone it and run the project locally.
https://github.com/mwinteringham/restful-booker

Here's the E-commerce side live online:
https://www.saucedemo.com/

### Test Automation

Your job as new Test Engineer is to create a series of visual tests that covers all scenarios provided:

- standard_user = No errors and the flow goes well until checkout is finished.
- locked_out_user = The user can't enter the site
- problem_user = The user has some problems loging in
- performance_glitch_user = The user experiences perfoance issues that make the page slow.

Note: All scenarios have their own username and password provided in the live example.

#### Submitting your completed code

- Fork the repository by clicking the "Fork" icon at the top left corner of the link provided to you. (You are here!)

- Download the project using the download icon on the left sidenav, and work on the 3 parts locally,

- Once finished, Email us the .zip or a link to an accessible location of it.

_NOTE: Using Stackblitz browser for this assessment is NOT MANDATORY. If you have any difficulties using Stackblitz, feel free to use a different setup that you are more comfortable with by using our README.md from this assessment as direction document. If you use a different setup, please remember to include a readme that has setup instructions._

Good luck!
