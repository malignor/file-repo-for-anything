import { task1, task2, task3, task4, Price, PriceEngine, User } from './part-1';

describe('#Part1', () => {
  // ======= TASK SPECIFIC TESTS - HIGH LEVEL =========
  test('T01-01 task 1 - (John Doe) a (user) buying [wine] for (food) industry'),
    () => {
      expect(task1()).toEqual({
        priceResult: { lowestPrice: 20, highestPrice: 500 },
      });
    };

  test(
    'T01-02 task 1 structure - if task 1 test fails, is the structure at least correct?'
  ),
    () => {
      expect(task1()).toHaveProperty('priceResult.lowestPrice');
      expect(task1()).toHaveProperty('priceResult.highestPrice');
    };

  test(
    'T02-01 task 2 - (Jane Doe) a (broker) doing [food delivery] activity for (food) industry'
  ),
    () => {
      expect(task2()).toEqual({
        priceResult: { lowestPrice: 20, highestPrice: 500 },
        possiblePrices: [
          { fee: 10, premium: 500, industry: 'food' },
          { fee: 15, premium: 200, industry: 'food' },
        ],
      });
    };

  test(
    'T02-02 task 2 structure - if task 2 test fails, is the structure at least correct?'
  ),
    () => {
      expect(task2()).toHaveProperty('priceResult.lowestPrice');
      expect(task2()).toHaveProperty('priceResult.highestPrice');
      expect(task2()).toHaveProperty('possiblePrices.premium');
    };

  test(
    'T03-01 task 3 - (John Smith) a (user) doing [BarLounge, FoodDelivery] for (food) industry and DOESNT agree with ToC'
  ),
    () => {
      expect(task3()).toEqual({
        priceResult: { desciption: 'No price selected' },
      });
    };

  test(
    'T03-02 task 3 structure - if task 2 test fails, is the structure at least correct?'
  ),
    () => {
      expect(task3()).toHaveProperty('priceResult.description');
    };

  test(
    'T04-01 task 4 - (John Smith) a (broker) doing [CoffeeShop] for (food) industry and DOESNT agree with ToC'
  ),
    () => {
      expect(task4()).toEqual({
        priceResult: { desciption: 'No price selected' },
        possiblePrices: [
          { fee: 10, premium: 500, industry: 'food' },
          { fee: 15, premium: 200, industry: 'food' },
        ],
      });
    };

  test(
    'T04-02 task 4 structure - if task 2 test fails, is the structure at least correct?'
  ),
    () => {
      expect(task4()).toHaveProperty('priceResult.description');
      expect(task4()).toHaveProperty('possiblePrices.premium');
    };

  // ======= COVERAGE TESTS - TEST EACH PATH =========
  const dummyPrice1 = new Price({ premium: 7, fee: 1, industry: 'legal' });
  const dummyPrice2 = new Price({ premium: 13, fee: 3, industry: 'legal' });
  const dummyPrice3 = new Price({ premium: 7919, fee: 113, industry: 'legal' });
  const priceSet = [dummyPrice1, dummyPrice2, dummyPrice3];
  const priceEngine = new PriceEngine(priceSet);
  const emptyEngine = new PriceEngine();

  const cUserUser = new User({
    firstName: 'GetPrice',
    lastName: 'User',
    role: 'user',
    questionBank: {
      industry: 'legal',
      industryActivities: ['AutoTestU'],
      worksOutsideOfCanada: 'no',
      agreesWithTermsAndConds: 'yes',
    },
  });

  const cUserBroker = new User({
    firstName: 'GetPrice',
    lastName: 'Broker',
    role: 'broker',
    questionBank: {
      industry: 'legal',
      industryActivities: ['AutoTestB'],
      worksOutsideOfCanada: 'no',
      agreesWithTermsAndConds: 'yes',
    },
  });

  const cUserNull = new User({
    firstName: 'GetPrice',
    lastName: 'Invalid',
    role: null,
    questionBank: {
      industry: 'legal',
      industryActivities: ['AutoTestN'],
      worksOutsideOfCanada: 'no',
      agreesWithTermsAndConds: 'yes',
    },
  });

  test('C01-01 getPrice with user user'),
    () => {
      expect(cUserUser.getPrice(priceEngine)).toHaveProperty('priceResult');
    };

  test('C01-02 getPrice with broker user'),
    () => {
      expect(cUserBroker.getPrice(priceEngine)).toHaveProperty('priceResult');
    };

  test('C01-03 getPrice with invalid user type'),
    () => {
      expect(cUserNull.getPrice(priceEngine)).toThrow('invalid user type');
    };

  test('C02-01 getPrice with empty priceEngine'),
    () => {
      expect(emptyEngine.getPrice(cUserBroker)).toEqual({
        priceResult: { desciption: 'No price selected' },
      });
    };

  test('C03-01 user type checking functions match'),
    () => {
      expect(cUserUser.isUser()).toBeTruthy;
      expect(cUserUser.isBroker()).toBeFalsy;
      expect(cUserBroker.isUser()).toBeFalsy;
      expect(cUserBroker.isBroker()).toBeTruthy;
      expect(cUserNull.isUser()).toBeFalsy;
      expect(cUserNull.isBroker()).toBeFalsy;
    };

  test('C04-01 question bank is right for user'),
    () => {
      expect(cUserUser.getQuestionBank()).toEqual({
        industry: 'legal',
        industryActivities: ['AutoTestU'],
        worksOutsideOfCanada: 'no',
        agreesWithTermsAndConds: 'yes',
      });
    };
});
