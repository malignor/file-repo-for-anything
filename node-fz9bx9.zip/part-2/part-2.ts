export class testClickup {
  /*
   * This is the beginning of the class that operates as a test wrapper for the Clickup API.
   * The methods for Authorization API have been defined to get you started.
   */

  token: string;
  url: string;

  constructor(token: string, url: string) {
    this.token = token;
    this.url = url;
  }

  public async authGetAccessToken(
    client_idStr: string,
    client_secretStr: string,
    codeStr: string,
    junkStr: string
  ) {
    // modified from https://clickup.com/api/clickupreference/operation/GetAccessToken/
    const query = new URLSearchParams({
      client_id: client_idStr,
      client_secret: client_secretStr,
      code: codeStr,
    }).toString();

    const queryWithJunk = new URLSearchParams({
      client_id: client_idStr,
      client_secret: client_secretStr,
      code: codeStr,
      junk: junkStr,
    }).toString();

    if (junkStr.length > 0) {
      const resp = await fetch(this.url + `oauth/token?${queryWithJunk}`, {
        method: 'POST',
      });
      const data = await resp.text();
      return data;
    } else {
      const resp = await fetch(this.url + `oauth/token?${query}`, {
        method: 'POST',
      });
      const data = await resp.text();
      return data;
    }
  }

  public async authGetAuthorizedUser(tokenStr: string, junkStr: string) {
    // modified from https://clickup.com/api/clickupreference/operation/GetAuthorizedUser/
    if (junkStr.length > 0) {
      const resp = await fetch(this.url + `user`, {
        method: 'GET',
        headers: {
          Authorization: tokenStr,
          junk: junkStr,
        },
      });

      const data = await resp.text();
      return data;
    } else {
      const resp = await fetch(this.url + `user`, {
        method: 'GET',
        headers: {
          Authorization: tokenStr,
        },
      });

      const data = await resp.text();
      return data;
    }
  }

  public async authGetAuthorizedTeams(tokenStr: string, junkStr: string) {
    // modified from https://clickup.com/api/clickupreference/operation/GetAuthorizedTeams/
    if (junkStr.length > 0) {
      const resp = await fetch(this.url + `team`, {
        method: 'GET',
        headers: {
          Authorization: tokenStr,
          junk: junkStr,
        },
      });

      const data = await resp.text();
      return data;
    } else {
      const resp = await fetch(this.url + `team`, {
        method: 'GET',
        headers: {
          Authorization: tokenStr,
        },
      });

      const data = await resp.text();
      return data;
    }
  }

  // continue onward, down all the endpoints and their operations.
}
