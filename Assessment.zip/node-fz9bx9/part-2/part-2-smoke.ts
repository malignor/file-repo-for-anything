
  /*
   * This is a smoke test for the Clickup API that tests with the data hierarchy in mind.
   * These have been pulled from https://clickup.com/api and then parameterized to maintain dependency / hierarchy.
   */



/* If you want to test with data pulled from 2023-02-01 browser interactions:
 *	Workspace: 36805086
 *		Users: [54646532]
 *		Spaces: [60688588, 32144572, 61464863, 60688577]
 *
 *	Space 60688588 Folders: [114810517, 114810520, 114810521, 128301679, 110477694]
 *		Folder 114810517 Lists: [192811261, 192811259]
 *			List 192811261 Tasks: [2wakgt7, 2wub1yd, 2nnm1gd, 2nnm1gc, 2nnm1ga, 2nnm1g8]
 *			List 192811259 Tasks: [2nnm1g7, 2nnm1g5]
 *		Folder 114810520 Lists: [192811263, 192811264]
 *		Folder 114810521 Lists: [192811266, 192811265, 192811267]	
 * 
 *  This is not all the data, but enough to do example tests for each transaction. See the Bwoser Datamine file.
 */


	const token = 'pk_54646532_7STX20R3MPRLAL0YR2LRKMQMPRV87PGD'
	const url = 'https://api.clickup.com/api/v2/'

	const workspace = '36805086'
	const user = '54646532'
	const space = '60688588'
	const folder = '114810517'
	const list = '192811261'
	const task = '2wakgt7'
	
	let cDT = new Date();
	const testId = ""+cDT.getFullYear()+cDT.getMonth()+cDT.getDate()+cDT.getHours()+cDT.getMinutes()+cDT.getSeconds()+"-"+Math.floor(Math.random()*999)

	function generateUUID(): string {  
		return 'xxxx-xxxx-xxx-xxxx'.replace(/[x]/g, (c) => {  
			const r = Math.floor(Math.random() * 16);  
			return r.toString(16);  
	  });  
	}
	
	// == CREATE A SPACE ==
	const teamId = workspace;
	const respCs01 = await fetch(
	  `${url}/team/${teamId}/space`,
	  {
		method: 'POST',
		headers: {
		  'Content-Type': 'application/json',
		  Authorization: token
		},
		body: JSON.stringify({
		  name: 'New Space ${testId}',
		  multiple_assignees: true,
		  features: {
			due_dates: {
			  enabled: true,
			  start_date: false,
			  remap_due_dates: true,
			  remap_closed_due_date: false
			},
			time_tracking: {enabled: false},
			tags: {enabled: true},
			time_estimates: {enabled: true},
			checklists: {enabled: true},
			custom_fields: {enabled: true},
			remap_dependencies: {enabled: true},
			dependency_warning: {enabled: true},
			portfolios: {enabled: true}
		  }
		})
	  }
	);
	const dataSpace = await respCs01.json();
	console.log(dataSpace);
	
	const newSpaceId = dataSpace.id;
	
	// Now we have a space.
	// TODO: Add tests for Get Spaces, Get Space and Update Space. 
	//		 Wait until the end for the Delete Space test.
	
	// == CREATE A FOLDER ==
	const resp = await fetch(
	  `${url}/space/${newSpaceId}/folder`,
	  {
		method: 'POST',
		headers: {
		  'Content-Type': 'application/json',
		  Authorization: token
		},
		body: JSON.stringify({name: 'New Folder ${testId}'})
	  }
	);
	const dataFolder = await resp.json();
	console.log(dataFolder);
	
	const newFolderId = dataFolder.id;
	
	// Now we have a folder in our new space.
	// TODO: Add tests for Get Folder and Get Folders and Update Folder.
	//		 Wait until the end for the Delete Folder test.

	// == CREATE A LIST ==
	const resp = await fetch(
	  `${url}/folder/${newFolderId}/list`,
	  {
		method: 'POST',
		headers: {
		  'Content-Type': 'application/json',
		  Authorization: token
		},
		body: JSON.stringify({
		  name: 'New List ${testId}',
		  content: 'New List Content ${testId}',
		  due_date: 1567780450202,
		  due_date_time: false,
		  priority: 1,
		  assignee: 183,
		  status: 'red'
		})
	  }
	);

	const dataList = await resp.json();
	console.log(dataList);	
	
	const newListId = dataList.id;
	
	// Now we have a list in our new folder.
	// TODO: Add tests for Get Lists and Get List and Update List.
	//		 Wait until the end for the Delete List test.

	// == CREATE A TASK ==
	const query = new URLSearchParams({
	  custom_task_ids: 'true',
	  team_id: '${workspace}'
	}).toString();

	const customUuid = generateUUID()
	
	const resp = await fetch(
	  `${url}/list/${newListId}/task?${query}`,
	  {
		method: 'POST',
		headers: {
		  'Content-Type': 'application/json',
		  Authorization: token
		},
		body: JSON.stringify({
		  name: 'New Task ${testId}',
		  description: 'New Task Description',
		  assignees: [183],
		  tags: ['tag name ${testId}'],
		  status: 'Open',
		  priority: 3,
		  due_date: 1608369194377,
		  due_date_time: false,
		  time_estimate: 8640000,
		  start_date: 1667780450202,
		  start_date_time: false,
		  notify_all: true,
		  parent: null,
		  links_to: null,
		  check_required_custom_fields: true,
		  custom_fields: [
			{
			  id: '${customUuid}',
			  value: 'This is a string of text added to a Custom Field.'
			}
		  ]
		})
	  }
	);

	const dataTask = await resp.json();
	console.log(data);
	
	const newTaskId = dataTask.id;
	
	// Now we have a task in our new list.
	// TODO: Add tests for Get Tasks and Get Task and Update Task, and GetTaskTimeInStatus
	
	// ================================================
	// ### ADD MORE TESTS FOR OTHER OPERATIONS HERE ###
	
		/* TESTS */
	
	// ### OPERATION TESTS END HERE ###
	// ================================
	
	// Delete New Task
	const query = new URLSearchParams({
	  custom_task_ids: 'true',
	  team_id: '${workspace}'
	}).toString();

	const taskId = '${newTaskId}';
	const resp = await fetch(
	  `${url}/task/${taskId}?${query}`,
	  {
		method: 'DELETE',
		headers: {
		  'Content-Type': '"application/json"',
		  Authorization: '${token}'
		}
	  }
	);

	const dataDelTask = await resp.text();
	console.log(data);
	
	
	// Delete New List
	const resp = await fetch(
	  `${url}/list/${newListId}`,
	  {
		method: 'DELETE',
		headers: {
		  'Content-Type': '"application/json"',
		  Authorization: '${token}'
		}
	  }
	);

	const dataDelList = await resp.text();
	console.log(data);
	
	// Delete New Folder
	const resp = await fetch(
	  `${url}/folder/${newFolderId}`,
	  {
		method: 'DELETE',
		headers: {
		  Authorization: '${token}'
		}
	  }
	);

	const dataDelFolder = await resp.text();
	console.log(data);
	
	// Delete New Space
	const resp = await fetch(
	  `${url}/space/${newSpaceId}`,
	  {
		method: 'DELETE',
		headers: {
		  Authorization: '${token}'
		}
	  }
	);

	const dataDelSpace = await resp.text();
	console.log(data);

export { }
