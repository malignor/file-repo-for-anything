###########
## NOTES ##
###########
 - This is not (yet) runnable, but I'm out of time.
 - In order to get this up and running, the following needs to be fixed:
   - node-fetch needs to get defined. I installed it but for some reason there's something I'm missing. This will get part-2.ts working.
   - part-2-smoke.ts needs to be converted to a module with a method for each of the transactions. Then add its functionalist to a new file, part-2-smoke.spec.ts.
 - These are also not complete.
   - part-2-smoke.ts needs around a hundred or more additional tests, for all the other API operations.
   - part-2.ts will need a few hundred addtional tests, for all the variations on all the API operations.


############################
#### STRATEGIC APPROACH ####
############################

Create a class (Javascript, Typescript, etc.) that performs API operations, acting as a simple wrapper for each Clickup API endpoint.

Design a method for each of these endpoints. This is 90% done already from each endpoint. For example, to make the method to test the CReate Folder operation, look at https://clickup.com/api/clickupreference/operation/CreateFolder/ and see the samples on the right hand side.

 --> Method Args: Each has the endpoint parameters as arguments of the method call. However, where these parameters are restricted, their arguments are more loosly defined to allow for negative testing (to allow bad or missing parameters). Use they original datatype in the parameter name for ease of reading & troubleshooting (for example "count_int: string" as an argument where the API parameter "count" is of type integer).
  - Include the token as an argument (so we can test invalid or missing tokens)
  - Include a "garbage" argument to test malformed requests with a extra junk parameter

 --> Return Value: The return value for each method is simply the response from the API's endpoint.

Use Jest to write the functional test cases by interacting with the class and its methods.
For each endpoint you can test the following:
  Test with missing token
  Test with invalid token
  Test with extra parameter
  For each request parameter...
    - test with it missing. Optional parameters should respond well, and required parameters should return an appropriate error response.
    - test with it null. Nullable parameters should respond well, and required parameters should return an appropriate error response.
    - test the boundary cases if any (too many/too few characters for example)
    - test data sanitation by trying to insert code as data, to break the system
    - test incorrect data type where possible (may be difficult with strings)
    - where a parameter is a list, test too many or too few if there is a limit on the list size
    - where a parameter is an attachment, test with an empty file or an oversized file (which could be a timeout test), or test with a file that has malicious contents such as a virus.

----------------------------
== TESTING ACCESS CONTROL ==
----------------------------
The endpoints like /team/${teamId}/space?${query} or like team/${teamId}/task?${query} require access control, which mean we need to test with a particular team's token (for positive cases) or an invalid token (for negative cases). We also need the appropriate IDs, secrets and so on.

----------------------------------
== TESTING WITH DATA DEPENDENCY ==
----------------------------------
Various data items, like Tasks and Teams and Workspaces, have an associated dependency. For example a workspace belongs to a particular team, and spaces belong to a particular workspace.
Any test suite which includes these tests has to be run in proper order - for example a workspace must exist in order create a space within it.
Dependency is as follows:
 - Tasks depend on Lists
 - Lists depend on Folders
 - Folders depend on Spaces
 - Spaces depend on a Workspace
 - Users depend on Workspace
 - User groups depend on a Workspace

DEPENDENCY EXAMPLE: The DeleteTask endpoint operation.
In order to run the DeleteTask, you must first have a task to delete; run CreateTask prior.
In order to run CreateTask you need a list_id, which identifies the task's List; run CreateList prior.
In order to run CreateList you need a folder_id, which identifies the list's Folder; run CreateFolder prior.
In order to run CreateFolder you need a space_id, which identifies the folder's Space; run CreateSpace prior.
In order to run CreateSpace you need a Workspace team_id, identifying the space's team.
  Much of the endpoint operations eventually lead to Workspace as a dependency.

------------------------
== REGRESSION TESTING ==
------------------------
Make a folder for automated test scripts. Inside, make shell or batch scripts which execute these tests from the terminal/console, and store the output distinctly so that we can keep an archive of results.
Change the build scripts so that once the build and/or deploy is complete, test scripts are run.
These test scripts can also be run by crontab or windows scheduler so we can maintain the functional status of the product.
The folder of scripts, and their scheduled execution, function as an automaed regression suite.

---------------------------
== TEST CASE MAINTENANCE ==
---------------------------
As the API changes over time (with new releases for example), look for new endpoint operations to test, or missing ones to remove.
Adjust the regression suite as appropriate with these additions/ommisions.

-------------------------
== PERFORMANCE TESTING ==
-------------------------
Use JMeter, as it can do all the API performance testing out of the box. It's open source and free, no licensing fees. The reports are simple but effective, and follow industry standards.
